<?php

// File generated from our OpenAPI spec

namespace Stripe\Util;

class ApiVersion
{
    const CURRENT = '2024-12-18.acacia';
}
